package com.example.loginscreen

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.loginscreen.ui.theme.LoginScreenTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            LoginScreenTheme {
                Column(
                modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment =Alignment.CenterHorizontally
                ) {
                    simpleText()
                    usernameField()
                    passwordField()
                    simpleButton()
                }
            }
        }
    }
}

@Composable
fun simpleText()
{
    Text(text = "Login Form", modifier = Modifier.padding(16.dp), Color.White, 24.sp)
    Spacer(modifier = Modifier.height(16.dp))
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun usernameField()
{
    var username by remember{ mutableStateOf("")}
    TextField(value = username , onValueChange = {it -> username = it}, label = {Text(text = "User Name")})
    Spacer(modifier = Modifier.height(16.dp))
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun passwordField()
{
    var password by remember{ mutableStateOf("")}
    TextField(value = password , onValueChange = {it -> password = it}, label = {Text(text = "Password")})
    Spacer(modifier = Modifier.height(16.dp))
}

@Composable
fun simpleButton()
{
    Button(modifier = Modifier.padding(16.dp), onClick = { /*TODO*/ })
    {
        Text(text = "Login", fontSize = 24.sp)
    }
}

@Preview
@Composable
fun simpleTextPreview()
{
    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment =Alignment.CenterHorizontally
    ) {
        simpleText()
        usernameField()
        passwordField()
        simpleButton()
    }
}

