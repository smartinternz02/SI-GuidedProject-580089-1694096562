package com.example.diceroller

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.diceroller.ui.theme.DiceRollerTheme
import java.util.Random


class MainActivity : ComponentActivity() {
    private lateinit var textView: TextView
    private lateinit var button: Button
    private lateinit var imageView: ImageView


    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        textView = findViewById(R.id.textView)
        button = findViewById(R.id.button)
        imageView = findViewById(R.id.imageView)


        button.setOnClickListener {
            rollDice()
        }
    }

    private fun rollDice() {
        val random = Random()
        val randomNumber = random.nextInt(6) + 1
        val resultText = "The dice rolled $randomNumber"
        textView.text = resultText


        if (randomNumber == 1) {
            imageView.setImageResource(R.drawable.d1)
        } else if (randomNumber == 2) {
            imageView.setImageResource(R.drawable.d2)
        } else if (randomNumber == 3) {
            imageView.setImageResource(R.drawable.d3)
        } else if (randomNumber == 4) {
            imageView.setImageResource(R.drawable.d4)
        } else if (randomNumber == 5) {
            imageView.setImageResource(R.drawable.d5)
        } else {
            imageView.setImageResource(R.drawable.d6)
        }
    }
}